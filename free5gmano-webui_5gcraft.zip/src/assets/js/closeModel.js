export const closeModal = (element) => {
  element.closeModalEvent();
};